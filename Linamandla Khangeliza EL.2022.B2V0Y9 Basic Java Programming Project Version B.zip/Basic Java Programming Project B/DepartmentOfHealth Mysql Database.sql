drop database if exists `Department of Health`; #Linamandla Khangeliza EL.2022.B2V0Y9
create database `Department of Health`;

CREATE TABLE `Department of Health`.`Covid-19 Cases` (
    `Prov ID` INT(20) NOT NULL AUTO_INCREMENT,
    `Province` VARCHAR(18) NOT NULL,
    `Total Cases for 10 October 2020` INT(31) NOT NULL,
    `Percentage Total` DOUBLE NOT NULL,
    PRIMARY KEY (`Prov ID`)
);
  
  insert  into `Department of Health`.`Covid-19 Cases` (`Province`, `Total Cases for 10 October 2020`, `Percentage Total`)
  values
  ("Eastern Cape",90686,13.1),
  ("Free State",50552,7.3),
  ("Gauteng",222745,32.2),
  ("KwaZulu-Natal",120295,17.4),
  ("Limpopo",16233,2.3),
  ("Mpumalanga",28115,4.1),
  ("North West",30715,4.1),
  ("Northern Cape",18888,2.7),
  ("Western Cape",112667,16.3),
  ("Total",690896,100);