package mathematics;
import java.util.*;

/**
 *
 * @author Linamandla Khangeliza EL.2022.B2V0Y9
 */
public class Mathematics {

    public static void main(String[] args) {
        boolean end = false; // declare boolean end
        
        char [] operators = {'+','-','/','*'}; //declare operators array
        char sign; //declare sign
        
        int num1,num2,num,correctIndex,answer; // declare variables to integer 
        
        correctIndex = 0;
        end = true;
        
        TreeSet correctAns = new TreeSet (); // declare a variable to a TreeSet
        
        System.out.println("Welcome to Edureka Trivia Game"); // display welcome message
        do //do - while loop
        {
            Random signs = new Random(); // declare a variable to a Random
            int index = signs.nextInt(3); // declare the operators' index 
            sign = operators[index]; //declare sign to one of the operators in the array
          
            Random rand = new Random(); //declare a variable to a Random
            
            num = rand.nextInt(9); // set num to an index number from 0 and 9.
            num1 = num + 1;// declare num1 to a number from 1-9;
            
            num = rand.nextInt(9); // set num to an index number from 0 and 9. 
            num += 1;// declare num to a number from 1-9;
            
            if (num1 > num) // set num1 to be greater than num2 to avoid negative answers.
            {
                num2 = num;
            }
            else
            {
                num2 = num1;
                num1 = num2;
            }
            //check for operator calculate the correct answer
            if (sign == '+') 
            {
                answer = num1 + num2;
            }
            else if (sign == '-')
            {
                answer = num1 - num2;   
            }
            else if(sign == '/' )
            {        
                answer = num1 / num2;
            }
            else
            {
                answer = num1 * num2;
            }
            System.out.print("What is "+num1+sign+num2+"? ");// display the question to the user
            
            Scanner userAns = new Scanner(System.in); // set Scanner to a new variable
            double input = User(userAns);
            
            if (input == 999) //check if the user's is equal to 999
            {
                break; // break the loop
            }
            else
            {
                if (input == answer)
                {
                    System.out.println("Welldone, that's correct!"); //display message
                    correctAns.add(answer); // add correct answer to the TreesSet
                    correctIndex++;
                }
                else
                {
                    System.out.println("Wrong Answer!, the correct answer is: "+answer); //display message
                }
            }
        }while (end);
        System.out.println("Thank you for playing"); // display message
        System.out.println("Correct answers in Hashset"); // display message
        
        Object [] helper = correctAns.toArray(); //convert a TreeSet to an Array
        for (int i = 0; i < helper.length; i++) 
        {
            System.out.println(helper[i]); //display values in an array
        } 
    }
    static double User(Scanner userAns)
    {
        double ans = userAns.nextDouble(); // input user's answer
        return ans;
    }
}   