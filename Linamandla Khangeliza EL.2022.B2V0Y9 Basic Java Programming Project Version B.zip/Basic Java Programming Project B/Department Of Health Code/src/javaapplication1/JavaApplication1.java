/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication1;
import java.util.*;
import java.sql.*;

/**
 *
 * @author Linamandla Khangeliza EL.2022.B2V0Y9
 */
public class JavaApplication1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ProvincialDetails help = new ProvincialDetails();
        try
        {
            Class.forName(help.getDriver());
            Connection conn = DriverManager. getConnection(help.getUrl(), help.getUser(), help.getPassword());
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(help.getScript());
            
            while(rs.next())
            {
                System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getInt(3)+" "+rs.getDouble(4));
            }
        }
        catch(Exception e)
        {
            System.out.println("error: " + e);
        }
    }
}

class ProvincialDetails
{
    String url = "jdbc:mysql://localhost:3306/Department Of Health?zeroDateTimeBehavior=CONVERT_TO_NULL";
    String user = "root";
    String password = "123456";
    String driver = "com.mysql.jdbc.Driver";
    String script = "select * from `department of health`.`covid-19 cases`";
    
    public void setUrl(String url)
    {
        this.url = url;
    }
    public void setUser(String user)
    {
        this.user = user;
    }
    public void setPassword(String password)
    {
        this.password = password;
    }
    public void setDriver(String driver)
    {
        this.driver = driver;
    }
    public void setScript(String script)
    {
        this.script = script;
    }

    public String getUrl() 
    {
        return url;
    }
    public String getUser() 
    {
        return user;
    }
    public String getPassword() 
    {
        return password;
    }
    public String getDriver()
    {
        return driver;
    }
    public String getScript()
    {
        return script;
    }
}