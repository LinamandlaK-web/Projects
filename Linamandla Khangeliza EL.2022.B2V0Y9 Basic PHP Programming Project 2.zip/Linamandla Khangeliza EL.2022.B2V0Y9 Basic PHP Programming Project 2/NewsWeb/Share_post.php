<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $category = $_POST['category'];
    $content = $_POST['content'];
    $image_path = null;

    if ($_FILES['image']['name']) {
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($_FILES['image']['name']);
        if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
            $image_path = $target_file;
        } else {
            echo "Error uploading image.";
        }
    }

    $stmt = $mysqli->prepare("INSERT INTO posts (user_id, title, category, content, image_path) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("issss", $_SESSION['user_id'], $title, $category, $content, $image_path);

    if ($stmt->execute()) {
        echo "Post shared successfully.";
    } else {
        echo "Error sharing post.";
    }

    $stmt->close();
}

log_message("User ID " . $_SESSION['user_id'] . " shared a new post titled " . $title);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Share a Post</title>
</head>
<body>
    <form action="share_post.php" method="POST" enctype="multipart/form-data">
        <input type="text" name="title" placeholder="Title" required><br>
        <select name="category" required>
            <option value="Sport">Sport</option>
            <option value="Jobs">Jobs</option>
            <option value="Entertainment">Entertainment</option>
            <option value="Business">Business</option>
        </select><br>
        <textarea name="content" placeholder="Write your post..." required></textarea><br>
        <input type="file" name="image"><br>
        <button type="submit">Share</button>
    </form>
</body>
</html>