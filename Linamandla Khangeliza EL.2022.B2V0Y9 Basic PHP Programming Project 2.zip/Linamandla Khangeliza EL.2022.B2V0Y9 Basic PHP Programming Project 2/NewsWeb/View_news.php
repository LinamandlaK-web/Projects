<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$categories = ['Sport', 'Jobs', 'Entertainment', 'Business'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View News</title>
</head>
<body>
    <h1>Current News</h1>

    <?php foreach ($categories as $category): ?>
        <h2><?php echo $category; ?></h2>
        <?php
        $stmt = $mysqli->prepare("SELECT title, content, created_at FROM posts WHERE category = ? ORDER BY created_at DESC");
        $stmt->bind_param("s", $category);
        $stmt->execute();
        $stmt->bind_result($title, $content, $created_at);

        while ($stmt->fetch()): ?>
            <h3><?php echo $title; ?></h3>
            <p><?php echo $content; ?></p>
            <small>Posted on <?php echo $created_at; ?></small>
            <hr>
        <?php endwhile;

        $stmt->close();
        ?>
    <?php endforeach; ?>
</body>
</html>