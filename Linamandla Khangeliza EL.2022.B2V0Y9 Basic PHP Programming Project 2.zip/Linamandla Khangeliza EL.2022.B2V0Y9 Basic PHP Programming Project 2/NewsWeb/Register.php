<?php
require 'config.php';  // Include the database connection

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $gender = $_POST['gender'];
    $dob = $_POST['dob'];
    $email = $_POST['email'];
    $contact = $_POST['contact'];
    $receive_newsletter = isset($_POST['receive_newsletter']) ? 1 : 0;

    // Generate a random password
    $password = bin2hex(random_bytes(4));
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Prepare the SQL statement
    $stmt = $mysqli->prepare("INSERT INTO users (name, surname, gender, dob, email, contact, password, receive_newsletter) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssssi", $name, $surname, $gender, $dob, $email, $contact, $hashed_password, $receive_newsletter);

    if ($stmt->execute()) {
        // Send the email
        $subject = "Registration Successful";
        $message = "Your email: $email\nYour password: $password";
        $headers = "From: no-reply@newswebsite.com";

        if (mail($email, $subject, $message, $headers)) {
            echo "Registration successful! Please check your email for your login details.";
        } else {
            echo "Registration successful, but we couldn't send the email.";
        }
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}
?>
