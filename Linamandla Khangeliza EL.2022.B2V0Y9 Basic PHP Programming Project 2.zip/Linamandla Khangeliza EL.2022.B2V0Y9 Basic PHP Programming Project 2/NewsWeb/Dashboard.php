<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
</head>
<body>
    <h1>Welcome to Your Dashboard</h1>
    <ul>
        <li><a href="view_news.php">View News</a></li>
        <li><a href="change_password.php">Change Password</a></li>
        <li><a href="share_post.php">Share a Post</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</body>
</html>
