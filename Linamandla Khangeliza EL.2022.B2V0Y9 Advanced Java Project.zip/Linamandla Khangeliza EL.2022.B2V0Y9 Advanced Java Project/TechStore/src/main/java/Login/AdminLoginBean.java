package Login;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

@ManagedBean(name="ALB")
@RequestScoped
public class AdminLoginBean 
{
    private String userName;
    private String userPassword;
    private String dbuserName;
    private String dbpassword;
    
    Connection conn;
    Statement st;
    ResultSet rs;
    String mysql;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    public String getDbuserName() {
        return dbuserName;
    }

    public void setDbuserName(String dbuserName) {
        this.dbuserName = dbuserName;
    }

    public String getDbpassword() {
        return dbpassword;
    }

    public void setDbpassword(String dbpassword) {
        this.dbpassword = dbpassword;
    }
    
    public void dbData(String userName)
    {
        try
        {
            String driveUrl = "jdbc:mysql://localhost:3308/stock?zeroDateTimeBehavior=CONVERT_TO_NULL";
            String driveName = "jdbc:mysql://localhost:3308/stock?zeroDateTimeBehavior=CONVERT_TO_NULL [root on Default schema]";
            String drivePassword = "123456";
            String driver = "com.mysql.cj.jdbc.Driver";
            Class.forName(driver);
            conn = DriverManager.getConnection(driveUrl,driveName,drivePassword);
            st = conn.createStatement();
            mysql = "SELECT * FROM stock.admin where username like "+userName+";";
            rs = st.executeQuery(mysql);
            rs.next();
            dbuserName = rs.getString("username");
            dbpassword = rs.getString("password");
        }
        catch(ClassNotFoundException | SQLException ex)
        {
            System.out.println("Exception Occured in the process :" + ex);
        }
    }
    public String checkValidUser()
    {
        dbData(userName);
  
        if(userName.equalsIgnoreCase(dbuserName))
        {
            if(userPassword.equals(dbpassword))
                return "Admin/AdminView";
            else
            {
                return "Admin/AdminLogin";
            }
        }
        else
        {
            return "Admin/AdminLogin";
        }
    }
}
