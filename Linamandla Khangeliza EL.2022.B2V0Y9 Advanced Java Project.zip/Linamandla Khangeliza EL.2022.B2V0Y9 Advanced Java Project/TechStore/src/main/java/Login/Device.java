package Login;

import View.laptop;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Device {
    private String cart;
    private String name;
    private String descript;
    private double price;
    private int qty;

    public String getCart() {
        return cart;
    }

    public void setCart(String cart) {
        this.cart = cart;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescript() {
        return descript;
    }

    public void setDescript(String descript) {
        this.descript = descript;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }
    
    public String addCart()
    {
        String mysql = "";
        switch (cart) {
            case "Laptops":
                mysql = "insert into stock.laptops ";
                break;
            case "Desktops":
                mysql = "insert into stock.desktops ";
                break;
            case "Tablets":
                mysql = "insert into stock.tablets ";
                break;
            case "Accessories":
                mysql = "insert into stock.accessories ";
                break;
            default:
                break;
        }
        try
        {
            String driveUrl = "jdbc:mysql://localhost:3308/stock?zeroDateTimeBehavior=CONVERT_TO_NULL";
            String driveName = "jdbc:mysql://localhost:3308/stock?zeroDateTimeBehavior=CONVERT_TO_NULL [root on Default schema]";
            String drivePassword = "123456";
            String driver = "com.mysql.cj.jdbc.Driver";
            
            Class.forName(driver);
            Connection conn = DriverManager.getConnection(driveUrl,driveName,drivePassword);
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(mysql+"(`name`,price,`description`,image,quantity)"
                    +"values"
                    +"("+name+","+price+","+descript+",,"+qty+");");
            
            conn.close();
            st.close();
            rs.close();
        }
        catch(Exception e)
        {
            System.out.println("Error Data : " + e.getMessage());
        }
        return "Admin/AdminView";
    }
}