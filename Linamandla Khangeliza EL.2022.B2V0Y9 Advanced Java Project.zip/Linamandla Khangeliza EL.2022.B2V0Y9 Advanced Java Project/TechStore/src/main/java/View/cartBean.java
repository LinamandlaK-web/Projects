package View;

import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class cartBean 
{
    private List cartData = new ArrayList();
    private List getCartData ()
    {   
        int a = 0;
        try
        {
            String driveUrl = "jdbc:mysql://localhost:3308/stock?zeroDateTimeBehavior=CONVERT_TO_NULL";
            String driveName = "jdbc:mysql://localhost:3308/stock?zeroDateTimeBehavior=CONVERT_TO_NULL [root on Default schema]";
            String drivePassword = "123456";
            String driver = "com.mysql.cj.jdbc.Driver";
            
            Class.forName(driver);
            Connection conn = DriverManager.getConnection(driveUrl,driveName,drivePassword);
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM stock.orderDetails");
            
            while(rs.next())
            {
                int orderId = rs.getInt("idOrdDetails");
                int itemId = rs.getInt("idItem");
                int quantity = rs.getInt("qty");
                
                cartData.add(a,new cart(orderId,itemId,quantity));
                a++;
            }
            conn.close();
            st.close();
            rs.close();
        }
        catch(Exception e)
        {
            System.out.println("Error Data : " + e.getMessage());
        }
        return cartData;
    }
    public String Delete(int orderId)
    {
        try
        {
            String driveUrl = "jdbc:mysql://localhost:3308/stock?zeroDateTimeBehavior=CONVERT_TO_NULL";
            String driveName = "jdbc:mysql://localhost:3308/stock?zeroDateTimeBehavior=CONVERT_TO_NULL [root on Default schema]";
            String drivePassword = "123456";
            String driver = "com.mysql.cj.jdbc.Driver";
            
            Class.forName(driver);
            Connection conn = DriverManager.getConnection(driveUrl,driveName,drivePassword);
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("DELETE FROM stock.orderDetails WHERE idOrdDetails = "+orderId+";");
            conn.close();
            st.close();
            rs.close();
        }
        catch(Exception e)
        {
            System.out.println("Error Data : " + e.getMessage());
        }
        return "cart";
    }
    public String Buy()
    {
        try
        {
            String driveUrl = "jdbc:mysql://localhost:3308/stock?zeroDateTimeBehavior=CONVERT_TO_NULL";
            String driveName = "jdbc:mysql://localhost:3308/stock?zeroDateTimeBehavior=CONVERT_TO_NULL [root on Default schema]";
            String drivePassword = "123456";
            String driver = "com.mysql.cj.jdbc.Driver";
            
            Class.forName(driver);
            Connection conn = DriverManager.getConnection(driveUrl,driveName,drivePassword);
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM stock.orderDetails;");
            while(rs.next())
            {
                int orderId = rs.getInt("idOrdDetails");
                int itemId = rs.getInt("idItem");
                int quantity = rs.getInt("qty");
                st.executeQuery("insert into stock.orderInfo(idOrdInfo,`date`) values ("+orderId+","+LocalDate.now()+");");
            }
            st.executeQuery("TRUNCATE Table stock.Details;");
            conn.close();
            st.close();
            rs.close();
        }
        catch(Exception e)
        {
            System.out.println("Error Data : " + e.getMessage());
        }
        return "index";
    }
}