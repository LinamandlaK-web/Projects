package View;

import java.sql.Blob;
import javax.faces.bean.ManagedBean;

@ManagedBean(name="VLap")
public class laptop {
    private int idlaptop;
    private String name;
    private String description;
    private double price;
    private int quantity;
    private String imageLocation;

    public laptop(int idlaptop, String imageLocation, String name, String description, double price, int quantity) {
        this.idlaptop = idlaptop;
        this.name = name;
        this.description = description;
        this.price = price;
        this.quantity = quantity;
        this.imageLocation = imageLocation;
    }

    public laptop(int idlaptop, String imageLocation, String name, String description, double price) {
        this.idlaptop = idlaptop;
        this.name = name;
        this.description = description;
        this.price = price;
        this.imageLocation = imageLocation;
    }
    
    public int getIdlaptop() {
        return idlaptop;
    }

    public void setIdlaptop(int idtablet) {
        this.idlaptop = idtablet;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getImageLocation() {
        return imageLocation;
    }

    public void setImageLocation(Blob image) {
        this.imageLocation = imageLocation;
    }
}