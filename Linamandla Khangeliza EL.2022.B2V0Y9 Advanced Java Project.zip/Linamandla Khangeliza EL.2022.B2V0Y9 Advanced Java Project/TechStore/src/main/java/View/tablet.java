package View;

import java.sql.Blob;
import javax.faces.bean.ManagedBean;

@ManagedBean(name="VTab")
public class tablet {
    private int idtablet;
    private String name;
    private String description;
    private double price;
    private int quantity;
    private String imageLocation;

    public tablet(int idtablet, String image, String name, String description, double price, int quantity) {
        this.idtablet = idtablet;
        this.name = name;
        this.description = description;
        this.price = price;
        this.quantity = quantity;
        this.imageLocation = imageLocation;
    }

    public tablet(int idtablet, String image, String name, String description, double price) {
        this.idtablet = idtablet;
        this.name = name;
        this.description = description;
        this.price = price;
        this.imageLocation = imageLocation;
    }

    public int getIdtablet() {
        return idtablet;
    }

    public void setIdtablet(int idtablet) {
        this.idtablet = idtablet;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }   

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getImageLocation() {
        return imageLocation;
    }

    public void setImageLocation(String image) {
        this.imageLocation = imageLocation;
    }
}