package View;

import java.sql.Blob;
import javax.faces.bean.ManagedBean;

@ManagedBean(name="VAcc")
public class accessory {
    private int idaccessory;
    private String name;
    private String description;
    private double price;
    private int quantity;
    private String imageLocation;

    public accessory(int idaccessory,String imageLocation, String name, String description, double price, int quantity) {
        this.idaccessory = idaccessory;
        this.name = name;
        this.description = description;
        this.price = price;
        this.quantity = quantity;
        this.imageLocation = imageLocation;
    }

    public accessory(int idaccessory,String imageLocation, String name, String description, double price) {
        this.idaccessory = idaccessory;
        this.name = name;
        this.description = description;
        this.price = price;
        this.imageLocation = imageLocation;
    }
    
    public int getIdaccessory() {
        return idaccessory;
    }

    public void setIdaccessory(int idaccessory) {
        this.idaccessory = idaccessory;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getImageLocation() {
        return imageLocation;
    }

    public void setImageLocation(String image) {
        this.imageLocation = imageLocation;
    }
}