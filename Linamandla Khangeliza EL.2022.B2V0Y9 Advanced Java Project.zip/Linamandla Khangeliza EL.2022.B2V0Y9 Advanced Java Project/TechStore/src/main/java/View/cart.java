package View;

public class cart {
    private int idOrder;
    private int idItem;
    private int qty;

    public cart(int idOrder, int idItem, int qty) {
        this.idOrder = idOrder;
        this.idItem = idItem;
        this.qty = qty;
    }

    public int getIdOrder() {
        return idOrder;
    }

    public void setIdOrder(int idOrder) {
        this.idOrder = idOrder;
    }

    public int getIdItem() {
        return idItem;
    }

    public void setIdItem(int idItem) {
        this.idItem = idItem;
    }

    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }
}
