package View;

import java.util.*;
import java.sql.*;

public class desktopBean 
{ 
    private List desktopData = new ArrayList();
    private List getDesktopData ()
    {   
        int a = 0;
        try
        {
            String driveUrl = "jdbc:mysql://localhost:3308/stock?zeroDateTimeBehavior=CONVERT_TO_NULL";
            String driveName = "jdbc:mysql://localhost:3308/stock?zeroDateTimeBehavior=CONVERT_TO_NULL [root on Default schema]";
            String drivePassword = "123456";
            String driver = "com.mysql.cj.jdbc.Driver";
            
            Class.forName(driver);
            Connection conn = DriverManager.getConnection(driveUrl,driveName,drivePassword);
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM stock.desktops");
            
            while(rs.next())
            {
                int id = rs.getInt("idaccessory");
                String nam = rs.getString("name");
                String descript = rs.getString("description");
                double pric = rs.getDouble("price");
                int qty = rs.getInt("quantity");
                String blob = rs.getString("image");
                
                desktopData.add(a,new desktop(id,blob, nam,descript,pric,qty));
                desktopData.add(a,new desktop(id,blob,nam,descript,pric));
                a++;
            }
            conn.close();
            st.close();
            rs.close();
        }
        catch(Exception e)
        {
            System.out.println("Error Data : " + e.getMessage());
        }
        return desktopData;
    }
}