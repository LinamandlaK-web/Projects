package Select;

import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import java.io.Serializable;

@SessionScoped
@ManagedBean(name="VLap")
public class tablet implements Serializable {
    private int idtablet;
    private String name;
    private String description;
    private double price;
    private Blob image;
    private int quantity;
    private int custQty;

    public tablet(int idtablet, Blob image, String name, String description, double price) {
        this.idtablet = idtablet;
        this.name = name;
        this.description = description;
        this.price = price;
        this.image = image;
    }
    
    public int getIdtablet() {
        return idtablet;
    }

    public void setIdlaptop(int idtablet) {
        this.idtablet = idtablet;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public Blob getImage() {
        return image;
    }

    public void setImage(Blob image) {
        this.image = image;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getCustQty() {
        return custQty;
    }

    public void setCustQty(int custQty) {
        this.custQty = custQty;
    }
    
    private List tabletData = new ArrayList();
    private List getTabletData ()
    {   
        int a = 0;
        try
        {
            String driveUrl = "jdbc:mysql://localhost:3306/stock?zeroDateTimeBehavior=CONVERT_TO_NULL";
            String driveName = "jdbc:mysql://localhost:3306/stock?zeroDateTimeBehavior=CONVERT_TO_NULL [root on Default schema]";
            String drivePassword = "GmscA05%";
            String driver = "com.mysql.cj.jdbc.Driver";
            
            Class.forName(driver);
            Connection conn = DriverManager.getConnection(driveUrl,driveName,drivePassword);
            Statement st = conn.createStatement();
            String mysql = "SELECT idtablet,name,description,price "
                    + "FROM stock.tablets where idtablet = "+idtablet;
            ResultSet rs = st.executeQuery(mysql);
            
            while(rs.next())
            {
                int id = rs.getInt("idtablet");
                String nam = rs.getString("name");
                String descript = rs.getString("description");
                double pric = rs.getDouble("price");
                int qty = rs.getInt("quantity");
                Blob blob = rs.getBlob("image");
                
                tabletData.add(a,new tablet(id,blob,nam,descript,pric));
                a++;
            }
            conn.close();
            st.close();
            rs.close();
        }
        catch(Exception e)
        {
            System.out.println("Error Data : " + e.getMessage());
        }
        return tabletData;
    }
    public String lapOveral()
    {
        try
        {
            String driveUrl = "jdbc:mysql://localhost:3306/stock?zeroDateTimeBehavior=CONVERT_TO_NULL";
            String driveName = "jdbc:mysql://localhost:3306/stock?zeroDateTimeBehavior=CONVERT_TO_NULL [root on Default schema]";
            String drivePassword = "GmscA05%";
            String driver = "com.mysql.cj.jdbc.Driver";
            
            Class.forName(driver);
            Connection conn = DriverManager.getConnection(driveUrl,driveName,drivePassword);
            Statement st = conn.createStatement();
            int diff = custQty-quantity;
            String mysql = "UPDATE stock.laptops SET quantity = "+diff+"WHERE idlaptop="+idtablet+";";
            ResultSet rs = st.executeQuery(mysql);
            mysql = "insert into stock.orderdetails(idItem,qty)"
                    + "values"
                    + "("+idtablet+","+custQty+");";
            
            rs = st.executeQuery(mysql);
            conn.close();
            st.close();
            rs.close();
        }
        catch(Exception e)
        {
            System.out.println("Error Data : " + e.getMessage());
        }
        return "Order.tablet";
    }
}