package Select;

import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import java.io.Serializable;

@SessionScoped
@ManagedBean(name="VLap")
public class desktop implements Serializable {
    private int iddesktop;
    private String name;
    private String description;
    private double price;
    private String imageLocation;
    private int quantity;
    private int custQty;

    public desktop(int iddesktop, String imageLocation, String name, String description, double price) {
        this.iddesktop = iddesktop;
        this.name = name;
        this.description = description;
        this.price = price;
        this.imageLocation = imageLocation;
    }
    
    public int getIdtablet() {
        return iddesktop;
    }

    public void setIdlaptop(int idtablet) {
        this.iddesktop = iddesktop;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getImageLocation() {
        return imageLocation;
    }

    public void setImageLocation(String imageLocation) {
        this.imageLocation = imageLocation;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getCustQty() {
        return custQty;
    }

    public void setCustQty(int custQty) {
        this.custQty = custQty;
    }
    
    private List desktopData = new ArrayList();
    private List getDesktopData ()
    {   
        int a = 0;
        try
        {
            String driveUrl = "jdbc:mysql://localhost:3306/stock?zeroDateTimeBehavior=CONVERT_TO_NULL";
            String driveName = "jdbc:mysql://localhost:3306/stock?zeroDateTimeBehavior=CONVERT_TO_NULL [root on Default schema]";
            String drivePassword = "GmscA05%";
            String driver = "com.mysql.cj.jdbc.Driver";
            
            Class.forName(driver);
            Connection conn = DriverManager.getConnection(driveUrl,driveName,drivePassword);
            Statement st = conn.createStatement();
            String mysql = "SELECT iddesktop,name,description,price "
                    + "FROM stock.desktops where iddesktop = "+iddesktop;
            ResultSet rs = st.executeQuery(mysql);
            
            while(rs.next())
            {
                int id = rs.getInt("iddesktop");
                String nam = rs.getString("name");
                String descript = rs.getString("description");
                double pric = rs.getDouble("price");
                int qty = rs.getInt("quantity");
                String blob = rs.getString("image");
                
                desktopData.add(a,new desktop(id,blob,nam,descript,pric));
                a++;
            }
            conn.close();
            st.close();
            rs.close();
        }
        catch(Exception e)
        {
            System.out.println("Error Data : " + e.getMessage());
        }
        return desktopData;
    }
    public String deskOveral()
    {
        try
        {
            String driveUrl = "jdbc:mysql://localhost:3306/stock?zeroDateTimeBehavior=CONVERT_TO_NULL";
            String driveName = "jdbc:mysql://localhost:3306/stock?zeroDateTimeBehavior=CONVERT_TO_NULL [root on Default schema]";
            String drivePassword = "GmscA05%";
            String driver = "com.mysql.cj.jdbc.Driver";
            
            Class.forName(driver);
            Connection conn = DriverManager.getConnection(driveUrl,driveName,drivePassword);
            Statement st = conn.createStatement();
            int diff = custQty-quantity;
            String mysql = "UPDATE stock.desktops SET quantity = "+diff+"WHERE idlaptop="+iddesktop+";";
            ResultSet rs = st.executeQuery(mysql);
            mysql = "insert into stock.orderdetails(idItem,qty)"
                    + "values"
                    + "("+iddesktop+","+custQty+");";
            
            rs = st.executeQuery(mysql);
            conn.close();
            st.close();
            rs.close();
        }
        catch(Exception e)
        {
            System.out.println("Error Data : " + e.getMessage());
        }
        return "Order.desktop";
    }
}