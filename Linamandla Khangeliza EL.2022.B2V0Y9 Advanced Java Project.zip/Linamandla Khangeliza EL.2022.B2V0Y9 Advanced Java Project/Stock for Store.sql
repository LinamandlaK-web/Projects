drop database if exists stock;
create database stock;

create table stock.laptops (
idlaptop int not null auto_increment,
`name` varchar(100) not null default "",
price double not null default 0,
`description` varchar(200) not null default"",
image blob,
quantity int not null default 0,
primary key (idlaptop));

insert into stock.laptops(`name`,price,`description`,image,quantity)
values
("MacBook Air M2",22500,"CPU:Apple M2, GPU:Apple M2, RAM:8GB, Storage:1TB SSD",'C:\Users\Linamandla\Documents\Linamandla Khangeliza EL.2022.B2V0Y9 Advanced Java Programming Project 1\Images\Laptops\macbook_air.jpg',10),
("Acer Swift 5(2022)",11500,"CPU:Intel Core i7-1260, GPU:Intergrated Intel Iris Xe Graphics, RAM:16GB, Storage:1TB SSD",'C:\Users\Linamandla\Documents\Linamandla Khangeliza EL.2022.B2V0Y9 Advanced Java Programming Project 1\Images\Laptops\acer_swift_5.jpg',10),
("Lenovo Chromebook Duet 5",10300,"CPU:Qualcomm Snapdragon 7c Gen 2, RAM:8GB, Storage:128GB eMMC",'C:\Users\Linamandla\Documents\Linamandla Khangeliza EL.2022.B2V0Y9 Advanced Java Programming Project 1\Images\Laptops\lenovo_chromebook.jpg',10),
("Asus Zenbook 14 OLED (Q409ZA)",12500,"CPU:Intel Core i5 -1240, GPU Intel Iris Xe, RAM:8GB, Storage:256GB",'C:\Users\Linamandla\Documents\Linamandla Khangeliza EL.2022.B2V0Y9 Advanced Java Programming Project 1\Images\Laptops\asus_zenbook.jpg',10),
("Lenovo Yoga 9i (Duet 8)",13700,"CPU:Intel Core i7-1360, GPU:Intel Iris Xe Graphics, RAM:16GB, Storage:512GB SSD",'C:\Users\Linamandla\Documents\Linamandla Khangeliza EL.2022.B2V0Y9 Advanced Java Programming Project 1\Images\Laptops\lenovo_yoga_9i.jpg',10);

create table stock.desktops (
iddesktop int not null auto_increment,
`name` varchar(100) not null default "",
price double not null default 0,
`description` varchar(200) not null default"",
image blob,
quantity int not null default 0,
primary key (iddesktop));

insert into stock.desktops(`name`,price,`description`,image,quantity)
values
("Lenovo Desktop PC H405",5700,"Windows 7 Home Premium, RAM:8GB, Storage:512B HDD",'C:\Users\Linamandla\Documents\Linamandla Khangeliza EL.2022.B2V0Y9 Advanced Java Programming Project 1\Images\Desktops\lenovo_desktop.jpg',10),
("HP Compaq CQ1140UKm Desktop",6500,"Windows 7 Home Premium, RAM:4GB, Storage:256 GB HDD",'C:\Users\Linamandla\Documents\Linamandla Khangeliza EL.2022.B2V0Y9 Advanced Java Programming Project 1\Images\Desktops\hp_compaq.jpg',10),
("Acer Aspire AM3400-B2082 Desktop",5500,"Windows 7 Home Premium, RAM:4GB, Storage:512B HDD",'C:\Users\Linamandla\Documents\Linamandla Khangeliza EL.2022.B2V0Y9 Advanced Java Programming Project 1\Images\Desktops\acer_aspire.jpg',10),
("Dell 23.8 Desktop",7200,"Windows 10 pro (64-bit), RAM:8GB, Storage:512B HDD",'C:\Users\Linamandla\Documents\Linamandla Khangeliza EL.2022.B2V0Y9 Advanced Java Programming Project 1\Images\Desktops\dell_23.8_desktop.jpg',10),
("HP Pavilion P6110F Desktop",5200,"Windows 7 Home Premium (64-bit), RAM:8GB, Storage:512B HDD",'C:\Users\Linamandla\Documents\Linamandla Khangeliza EL.2022.B2V0Y9 Advanced Java Programming Project 1\Images\Desktops\hp_pavilion.jpg',10);

create table stock.tablets (
idtablet int not null auto_increment,
`name` varchar(100) not null default "",
price double not null default 0,
`description` varchar(200) not null default"",
image blob,
quantity int not null default 0,
primary key (idtablet));

insert into stock.tablets(`name`,price,`description`,image,quantity)
values
("HP Pro Tablet 10 EE G1",11500,"Processor:Intel Atom Z3735F Storage:64GB Color:Black",'C:\Users\Linamandla\Documents\Linamandla Khangeliza EL.2022.B2V0Y9 Advanced Java Programming Project 1\Images\Tablets\hp_pro_tablet.jpg',10),
("Samsung Galaxy Book Tablet",10400,"Processor:Octa-core Storage:128GB Color:Black",'C:\Users\Linamandla\Documents\Linamandla Khangeliza EL.2022.B2V0Y9 Advanced Java Programming Project 1\Images\Tablets\samsung_galaxy_book.jpg',10),
("Tablet Technology Life G18 (10.1)",13500,"RAM:4GB Storage:64GB Color: Gold",'C:\Users\Linamandla\Documents\Linamandla Khangeliza EL.2022.B2V0Y9 Advanced Java Programming Project 1\Images\Tablets\tablet_technology_life_g18.jpg',10),
("Lenovo Chromebook Duet 10.1 Tablet",15000,"Processor:Outer-core Storage:128GB +Keyboard",'C:\Users\Linamandla\Documents\Linamandla Khangeliza EL.2022.B2V0Y9 Advanced Java Programming Project 1\Images\Tablets\lenovo_chromebook.jpg',10),
("Lenovo Yoga Tablet 8",5700,"Processor:MT8125/8389 Core 1.2 Storage:64GB Color:Silver",'C:\Users\Linamandla\Documents\Linamandla Khangeliza EL.2022.B2V0Y9 Advanced Java Programming Project 1\Images\Tablets\lenovo_yoga_tablet.jpg',10);

create table stock.accessories (
idaccessory int not null auto_increment,
`name` varchar(100) not null default "",
price double not null default 0,
`description` varchar(200) not null default"",
image blob,
quantity int not null default 0,
primary key (idaccessory));

insert into stock.accessories(`name`,price,`description`,image,quantity)
values
("Apple Airpods G2",2200,"Brand:Comply, Material:Plastic, Color:Black",'C:\Users\Linamandla\Documents\Linamandla Khangeliza EL.2022.B2V0Y9 Advanced Java Programming Project 1\Images\Accessories\airpods_g2.jpg',10),
("Logitech MX3 Mouse",1500,"Track:Anywhere event glass, Connection:USB dongle or Bluetooth Color:Black",'C:\Users\Linamandla\Documents\Linamandla Khangeliza EL.2022.B2V0Y9 Advanced Java Programming Project 1\Images\Accessories/mouse_logitech_mx3.jpg',10),
("Logitech Keyboard",1700,"K400 plus wireless touch Keyboard 920-007145, Color:Black",'C:\Users\Linamandla\Documents\Linamandla Khangeliza EL.2022.B2V0Y9 Advanced Java Programming Project 1\Images\Accessories\logitech_keyboard.jpg',10),
("Watt Universal Charger",500,"Laptops charger even Macbooks, Color:Black ",'C:\Users\Linamandla\Documents\Linamandla Khangeliza EL.2022.B2V0Y9 Advanced Java Programming Project 1\Images\Accessories\universal_laptop_charger.jpg',10),
("Tripp Lite Mobile Powerbank",730,"Portable 12 000mAh, USB charger Color:White",'C:\Users\Linamandla\Documents\Linamandla Khangeliza EL.2022.B2V0Y9 Advanced Java Programming Project 1\Images\Accessories\powerbank.jpg',10);

create table stock.orderInfo (
idOrdInfo int not null auto_increment,
`date` date not null,
primary key(idOrdInfo));

create table stock.orderDetails (
idOrdDetails int not null auto_increment,
idItem int not null,
qty int not null,
primary key(idOrdDetails));

create table stock.`admin` (
username varchar (30) not null,
`password` varchar (30) not null,
primary key(username));

insert into stock.`admin`(username,`password`)
values
("nicky","pass"),
("ricky","pass"),
("dicky","pass"),
("dawn","pass");